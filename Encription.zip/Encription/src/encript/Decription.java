package encript;
import java.util.regex.Pattern;

public class Decription extends Encription {


public static String decription(String messageToDecript) {

	int[] key = {2,50,25,78,11,183,21,36,51,6,72};
	StringBuilder stringBuilder = new StringBuilder();
	String[] separatedCode = messageToDecript.split(" ");
	for(int i = 0; i < separatedCode.length; i++) {
		int temp = i;
		while(temp>key.length-2) {
			temp -= key.length-2;
		}
		int number = 0;
		try {
		number = Integer.parseInt(separatedCode[i]);
		}
        catch (NumberFormatException ex){
          return "Key is not valid try again!";
        }
		char decriptedLetter = (char) (number - key[temp]);
		stringBuilder.append(decriptedLetter);
				temp = 0;
	}
		String decriptedMessage = stringBuilder.toString();
		return decriptedMessage;
}

}
