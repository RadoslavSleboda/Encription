package encript;
import java.util.Arrays;

public class Encription extends Menu {

	public static String encription(String messageToEncript) {
		StringBuilder stringBuilder = new StringBuilder();
		for(int i = 0;i < messageToEncript.length();i++) {
			char letterToEncript = messageToEncript.charAt(i);
				stringBuilder.append(encriptLetter(letterToEncript, i) + " ");
			}
		String encriptedMessage = stringBuilder.toString();
		return encriptedMessage;
	}
	
	public static int encriptLetter(char letterToEncript, int i) {
		int[] key = {2,50,25,78,11,183,21,36,51,6,72};
		while(i>key.length-2) {
			i -= key.length-2;
		}
		
		int encriptedLetter = letterToEncript+key[i];
		return encriptedLetter;
	}
	

}
