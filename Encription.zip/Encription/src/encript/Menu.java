package encript;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class Menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1037, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(10, 159, 974, 254);
		contentPane.add(textPane);
		
		JButton btnNewButton = new JButton("Encript message");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String x = Encription.encription(textPane.getText());
				textPane.setText(x);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnNewButton.setBounds(10, 10, 469, 67);
		contentPane.add(btnNewButton);
		
		JButton btnDecriptEncriptedMessage = new JButton("Decript encripted message");
		btnDecriptEncriptedMessage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String x = Decription.decription(textPane.getText());
				textPane.setText(x);
			}
		});
		btnDecriptEncriptedMessage.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnDecriptEncriptedMessage.setBounds(515, 10, 469, 67);
		contentPane.add(btnDecriptEncriptedMessage);
		
		JLabel lblNewLabel = new JLabel("Put message down below   ↓↓↓");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(20, 87, 482, 62);
		contentPane.add(lblNewLabel);
	}
}
